Python 3.11.4 (tags/v3.11.4:d2340ef, Jun  7 2023, 05:45:37) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
#Formatovani textu (python 2.x a 3.x VYRAZNE ODLISNE!)

"Kamarad [0] se narodil v roce {}.".format("Jirka",1980)
'Kamarad [0] se narodil v roce Jirka.'
"Kamarad {0} se narodil v roce {}.".format("Jirka",1980)
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    "Kamarad {0} se narodil v roce {}.".format("Jirka",1980)
ValueError: cannot switch from manual field specification to automatic field numbering
"Kamarad {} se narodil v roce {}.".format("Jirka",1980)
'Kamarad Jirka se narodil v roce 1980.'
"Kamarad {jmeno} se narodil v roce {rok}.".format(jmeno="Jirka",rok=1980)
'Kamarad Jirka se narodil v roce 1980.'
#Pouze pomocne pojmenovani, nejedna se o deklarovani promenne
#Parametrem metody format je seznam
sklad = ["pocitac","notebook","tablet","mobil"]
"Na skladu mame {0[1]} a {0[3]}".format(sklad)
'Na skladu mame notebook a mobil'
 #Parametr dictionary
d = dict(zvire="pes",vaha=40)
"Nas {0[zvire]} vazi {0[vaha]}kg".format(d)
'Nas pes vazi 40kg'

#Parametrem modul
import sys,math
"{0.pi} platform={1.platform}".format(math,sys)
'3.141592653589793 platform=win32'

#Parametrem promenna
prvek = "vodik"
cislo = 1
"Prvek {prvek} je elementem cislo {cislo}" #Chyba, takto jen pise
'Prvek {prvek} je elementem cislo {cislo}'
"Prvek {prvek} je elementem cislo {cislo}".format(**locals())
'Prvek vodik je elementem cislo 1'

#Zjednoduseni:
i = 1
k = 3
"Prvni cislo {}, druhe cislo {}.".format(i,k) #Priradi svorkam v poradi paramaetru i,k
'Prvni cislo 1, druhe cislo 3.'

# "f stringy"
jmeno = "Franta"
f"Muj kamarad se jmenuje {jmeno}"
'Muj kamarad se jmenuje Franta'
#Do svorek lze vkladat vyrazy, volani funkce atd..
#Od verze 3.8 je mozno v f stringu napsat, ZA vyrazem ve {} znak = s timto ucinkem:
f"Muj kamarad se jmenuje {jmeno=}"
"Muj kamarad se jmenuje jmeno='Franta'"
#Vhodne pro debug

>>> #Uvnitr {0:2} za dvojteckou mohu uvadet dalsi informace, napr pocet desetinnych mist
>>> # Plati pro fstringy i pro prazdne {} - napr {:2}
>>> #Nektere moznosti:
>>> #Zarovnani: < - vlevo ^ - na stred, > - vpravo
>>> #Znamenko: + vynucene, - jne, je-li potreba
>>> #Pred cele cislo vypsat prefix: 0b (binar), 0x (hexa), ...
>>> #Pomlcka (nebo jiny znak) - vyplnit pole do dane sirky timto znakem
>>> #, - oddelovat tisicu a milionu
>>> #Lze zadat presnost pro desetinnna cisla (pocet mist), ciselnou soustavu pro int:b, x
>>> 
>>> s = "Krasny den"
>>> "{0}".format(s)
'Krasny den'
>>> "{0:25}".format(s) # 25 - sirka pole
'Krasny den               '
>>> "{0:>25}".format(s) # 25 - sirka pole > - zarovani vpravo
'               Krasny den'
>>> "{0:->25}".format(s) # 25 - sirka pole > - zarovani vpravo + - vyplnit znakem pomlcka
'---------------Krasny den'
>>> "{0:-^25}".format(s) # 25 - sirka pole ^ - zarovani uprostred + - vyplnit znakem pomlcka
'-------Krasny den--------'
>>> '-------Krasny den--------'
'-------Krasny den--------'
>>> "{0:0=3}".format(7)
'007'
>>> "{0:.2f}".format(3.141592) # na 2 des. mista
'3.14'
>>> 
>>> #Konverze znakovych sad:
>>> text = "žluťoučký"
>>> text
'žluťoučký'
>>> text.encode("utf-16")
b'\xff\xfe~\x01l\x00u\x00e\x01o\x00u\x00\r\x01k\x00\xfd\x00'
>>> text
'žluťoučký'
>>> text.encode("ASCII")
Traceback (most recent call last):
  File "<pyshell#62>", line 1, in <module>
    text.encode("ASCII")
UnicodeEncodeError: 'ascii' codec can't encode character '\u017e' in position 0: ordinal not in range(128)
>>> text.encode("utf-8")
b'\xc5\xbelu\xc5\xa5ou\xc4\x8dk\xc3\xbd'
>>> text.encode("ASCII")
Traceback (most recent call last):
  File "<pyshell#64>", line 1, in <module>
    text.encode("ASCII")
UnicodeEncodeError: 'ascii' codec can't encode character '\u017e' in position 0: ordinal not in range(128)
