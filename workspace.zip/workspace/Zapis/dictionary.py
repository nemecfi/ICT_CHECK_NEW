Python 3.11.4 (tags/v3.11.4:d2340ef, Jun  7 2023, 05:45:37) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
Type "help", "copyright", "credits" or "license()" for more information.
SyntaxError: invalid syntax
#Datovy typ dictionary
d = {"id":1,"krestni":"Jirka","Prijmeni":"Novak"}
D
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    D
NameError: name 'D' is not defined. Did you mean: 'd'?
d
{'id': 1, 'krestni': 'Jirka', 'Prijmeni': 'Novak'}
d("prijmeni")
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    d("prijmeni")
TypeError: 'dict' object is not callable

d{"prijmeni"}
SyntaxError: invalid syntax
KeyboardInterrupt
KeyboardInterrupt
<class 'KeyboardInterrupt'>


d("Prijmeni")
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    d("Prijmeni")
TypeError: 'dict' object is not callable
type(d)
<class 'dict'>
d["Prijmeni"]
'Novak'
#Cyklus "pres" dictionary:
for key in d:
    print(key,d[key])

    
id 1
krestni Jirka
Prijmeni Novak
#Nektere metody dictionaries:
d.values()
dict_values([1, 'Jirka', 'Novak'])
d.key()
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    d.key()
AttributeError: 'dict' object has no attribute 'key'. Did you mean: 'keys'?
d.keys()
dict_keys(['id', 'krestni', 'Prijmeni'])
d.items()
dict_items([('id', 1), ('krestni', 'Jirka'), ('Prijmeni', 'Novak')])

#chybny klic (name), ktery tam neni:
d["name"]
Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    d["name"]
KeyError: 'name'

#Pristup k prvkum dictionary pomoci metody get:
d.get("krestni")
'Jirka'
#Neplatny klic vraci None (ale nevyvola chybu!!)
d.get("name")
#Interaktivni rezimm NEZOBRAZUJI nic!
print(d.get("name"))
None
d.get("name","Not found") #Kdyz get nenajede hodnotu "name" tak to vypise Not found
'Not found'
d.get("krestni","Not found") #Kdyz hodnotu najde, "not found" se nevypise
'Jirka'

#Nekolik zpusobu jak vytvorit dictionary:
d1 = {"id":1,"krestni":"Jirka","Prijmeni":"Novak"}
d1
{'id': 1, 'krestni': 'Jirka', 'Prijmeni': 'Novak'}
d2 = dict(id=1,krestni="Jirka",prijmeni="Novak")
d2
{'id': 1, 'krestni': 'Jirka', 'prijmeni': 'Novak'}
d3 = dict([("id",1),("krestni","Jirka"),("prijmeni","Novak")])
d3
{'id': 1, 'krestni': 'Jirka', 'prijmeni': 'Novak'}
d4 = dict(zip(("id","krestni","prijmeni"),(1,"Jirka","Novak")))
d4
{'id': 1, 'krestni': 'Jirka', 'prijmeni': 'Novak'}
#Funkce ZIP vytvori seznam tuplu (v podstate verzi d3)
#Dictionary je MENITELNY typ:
#Zmena polozky ve slovniku:
d1["krestni"] = "Jirkos"
d1
{'id': 1, 'krestni': 'Jirkos', 'Prijmeni': 'Novak'}
#Lze i pridavat polozky do dictionary
d1["telefon"] = "777666333"
d1
{'id': 1, 'krestni': 'Jirkos', 'Prijmeni': 'Novak', 'telefon': '777666333'}
#Vymaz polozky ve slovniku
del d1["telefon"]
d1
{'id': 1, 'krestni': 'Jirkos', 'Prijmeni': 'Novak'}

#Kopirovani dictionary
dcopy = d1 #Zkopiruje jen pointery
#Vytvoreni melke (shallow) kopie (funguje podobne jako rez [:] pro list)
dcopy = d1.copy
dcopy
<built-in method copy of dict object at 0x000001360F5D3540>
dcopy = d1.copy()
dcopy
{'id': 1, 'krestni': 'Jirkos', 'Prijmeni': 'Novak'}
del dcopy["krestni"]
dcopy
{'id': 1, 'Prijmeni': 'Novak'}
>>> d1
{'id': 1, 'krestni': 'Jirkos', 'Prijmeni': 'Novak'}
>>> #Original se nezmenil
>>> 
>>> #Problemy shallow copy (predvedeme na seznamech):
>>> seznam = [["a","b"],"r","s"]
>>> s[0]
Traceback (most recent call last):
  File "<pyshell#71>", line 1, in <module>
    s[0]
NameError: name 's' is not defined
>>> seznam[0]
['a', 'b']
>>> seznam[1]
'r'
>>> c = seznam.copy() # seznamy maji taky copy, totez jako c = seznam[:]
>>> c
[['a', 'b'], 'r', 's']
>>> c[] = "t"
SyntaxError: invalid syntax
>>> c[1] = "t"
>>> c
[['a', 'b'], 't', 's']
>>> seznam
[['a', 'b'], 'r', 's']
>>> #Prepisi prvek ve vnorenem seznamu
>>> c[0][1] = "x"
>>> c
[['a', 'x'], 't', 's']
>>> seznam
[['a', 'x'], 'r', 's']
>>> # zmenil "oba" ve vnorenych date - dusledek shallow copy
>>> # shallow copy kopiruje POUZE prvni uroven DAT!
>>> 
>>> #deepcopy - hluboka kopie - kopiruje data do libovolne urovne, resi problem shallow copy
>>> 
>>> seznam = [["a","b"],"r","s"]
>>> import copy
>>> deepCopy = copy.deepcopy(seznam)
>>> deepCopy[1] = "t"
>>> deepCopy
[['a', 'b'], 't', 's']
>>> seznam
[['a', 'b'], 'r', 's']
>>> deepCopy[0][1] = "x"
>>> deepCopy
[['a', 'x'], 't', 's']
>>> seznam
[['a', 'b'], 'r', 's']
