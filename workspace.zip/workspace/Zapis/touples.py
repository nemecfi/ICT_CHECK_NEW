Python 3.11.4 (tags/v3.11.4:d2340ef, Jun  7 2023, 05:45:37) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> #Datovy typ tuple
>>> #Datovy typ tuple (n-tice)
>>> jmena = ("Franta","Eva","Karel")
>>> jmena
('Franta', 'Eva', 'Karel')
>>> type(jmena)
<class 'tuple'>
>>> #Opet moznost pristupovat k prvkum pomoci indexu
>>> jmena[2]
'Karel'
>>> jmena[1:3]
('Eva', 'Karel')
>>> jmena[0] = "Jirka" #Je to chyba - tuples jsou NEMĚNNÉ
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    jmena[0] = "Jirka" #Je to chyba - tuples jsou NEMĚNNÉ
TypeError: 'tuple' object does not support item assignment
>>> 
>>> #Pro NEMENITELNA data jsou tuples EFEKTIVNEJSI!
>>> #Tuples lze obep scitac:
>>> jmena2 = ("Milan","Vitek","Filip")
>>> jmena3 = jmena + jmena2
>>> jmena3
('Franta', 'Eva', 'Karel', 'Milan', 'Vitek', 'Filip')
>>> #Vnorovani:
>>> vnorene = (jmena,jmena2)
>>> vnorene
(('Franta', 'Eva', 'Karel'), ('Milan', 'Vitek', 'Filip'))
>>> vnorene[1]
('Milan', 'Vitek', 'Filip')
>>> vnorene[1][1]
'Vitek'
>>> #Vnorovat lze i seznamy a dalsi viceprvkove typy
