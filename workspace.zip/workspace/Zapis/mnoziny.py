Python 3.11.4 (tags/v3.11.4:d2340ef, Jun  7 2023, 05:45:37) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> #Datovy typ mnozina (set)
>>> s = {5,"Franta",3,("a","b"),"Eva"}
>>> type(s)
<class 'set'>
>>> s
{'Eva', 3, 5, ('a', 'b'), 'Franta'}
>>> #V pythonu mnozina NENI USPORADANA, NEJDE INDEXOVAT
>>> 
>>> #Prazdna mnozina
>>> emptySet = set()
>>> len(emptySet)
0
>>> type(emptySet)
<class 'set'>
>>> 
>>> #Prvky setu museji byt "hashovatelne" typy:
>>> toupleT = (4,7)
>>> hash(t)
Traceback (most recent call last):
  File "<pyshell#13>", line 1, in <module>
    hash(t)
NameError: name 't' is not defined
>>> hash(toupleT)
-3793500297614796835
>>> toupleT1 = (5,12)
>>> hash(toupleT1)
4838433880829014589
>>> s = [4,7]
>>> hash(s) #Seznam je nejde hashovat, vyhodit error
Traceback (most recent call last):
  File "<pyshell#18>", line 1, in <module>
    hash(s) #Seznam je nejde hashovat, vyhodit error
TypeError: unhashable type: 'list'
>>> 
>>> #Nektere typy nejsou hashovatelne!!
>>> #Set smi obsahovat pouze HASHOVATELNE typy!
>>> chybna = {5,"Franta",3,["a","b"],"Eva"} #Bude chyba, jelikoz seznam neni HASHOVATELNY
Traceback (most recent call last):
  File "<pyshell#22>", line 1, in <module>
    chybna = {5,"Franta",3,["a","b"],"Eva"} #Bude chyba, jelikoz seznam neni HASHOVATELNY
TypeError: unhashable type: 'list'

#K dispozici je sada mnozinovych operaci (ukazka nejakych):
>>> s2 = {3,"Eva",44,"Karel"}
>>> s = {5,"Franta",3,("a","b"),"Eva"}
>>> rozdil = s.difference(s2)
>>> rozdil
{'Franta', 5, ('a', 'b')}
#rozdil = s - s2 #totez
>>> prunik = s.intersection(s2) #Prunik, vypise data ktere jsou v obouch setech
>>> prunik
{3, 'Eva'}

sjednoceni = s.union(s2) #Sjednoceni, vezme prvni mnozinu a proda to prvky z druhe, ktere tam jeste nejsou
>>> sjednoceni
{3, 'Franta', 5, 44, 'Eva', 'Karel', ('a', 'b')}

#Pridavani do setu:
>>> s.add("Jarda")
>>> s
{3, 'Franta', 5, 'Eva', ('a', 'b'), 'Jarda'}
>>> s.add("Franta") # Mnozina neprida duplicitni hodnotu a nevyvola ani chybu
>>> s
{3, 'Franta', 5, 'Eva', ('a', 'b'), 'Jarda'}
#Pridani nekolika prvku
>>> s.update([1,5,2])
>>> s
{1, 2, 3, 'Franta', 5, 'Eva', ('a', 'b'), 'Jarda'}
>>> s.update(1,5,2)
Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    s.update(1,5,2)
TypeError: 'int' object is not iterable

#Odebirani prvku z mnoziny
>>> s.discard(1,2)
Traceback (most recent call last):
  File "<pyshell#28>", line 1, in <module>
    s.discard(1,2)
TypeError: set.discard() takes exactly one argument (2 given)
>>> s.discard(1)
>>> s
{2, 3, 'Franta', 5, 'Eva', ('a', 'b'), 'Jarda'}

#Totez .remove(), ale vyovla chybu (KeyError), pokud hodnota neexistuje

#Cyklus pres mnozinu:
>>> for p in s:
>>>     print(p)s

2
3
Franta
5
Eva
('a', 'b')
Jarda
