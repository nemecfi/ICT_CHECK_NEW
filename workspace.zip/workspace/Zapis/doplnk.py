Python 3.11.4 (tags/v3.11.4:d2340ef, Jun  7 2023, 05:45:37) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
#Doplnky prikazu
#Zruseni objektu (promenne)
i = 5
i
5
del i
i
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    i
NameError: name 'i' is not defined. Did you mean: 'id'?
seznam = [1,2,3,4,5]
print(seznam)
[1, 2, 3, 4, 5]
del seznam[2:4]
seznam
[1, 2, 5]
#del smazal index 2,3
seznam = [1,2,3,4,5]
#Vyjmuti prku ze seznamu PODLE HONOTY (Nikoli podle indexu)


#Operator prirazeni (Assignment expression), vraci prirazenou hodnotu
jmeno = "Franta"
print (jmeno)
Franta
#Lze pouzit od verze 3.8 toto:
print(name:="Venca") #Vrati hodnotu Venca a naplni ji promennou name
Venca
print(name) #Pro kontrolu naplneni
Venca
#Nelze pouzit misto prikazu prirazeni (=)
x := 1 #chyba
SyntaxError: invalid syntax
#Zjednoduseni cteni vstupu, souboru...
while(vstup := input("Napis Text:")) != "": #cist, dokud nezada prazdnou hodnotu
    print(vstup)

Napis Text:asda
asda
Napis Text:55
55
Napis Text:
#Bez tohoto - nekonecny cyklus + break, nebo jednou nacist pred cyklem apod.
    
#"Vyraz" if
    
import sys
sys.platform
'win32'
typ = "Windows" if sys.platform.startswith("win") else ("Linux")
typ
'Windows'

#else u cyklu
i = 5
while i > 0:
    print(i)
    i -= 1
else: #Kod za else, se provede, pouze po standartním dokončení cyklu
    print("Konec cyklu")

5
4
3
2
1
Konec cyklu
#Else se nevypise, pokud dojde k breaku nebo exceptionu, cyklus musi skoncit uspesne
i = 5
while i > 0:
    i -= 1
    if i == 2:
        break
    else:
        pass
else:
    print("uspesny konec cyklu") #Jelikoz doslo v cyklu k "break" tak se else nevykonna


#else u exception + finally
    
try:
    cislo = int(input("cislo: "))
    print(cislo)
except ValueError as err:
    print(err)
else:   #Blok se vykonna pouze, kdyz nebylo exception
    print("Provedeno bez chyby")
finally:    #Blok se provede VZDY - pri NOK i OK, napr. pro zapis do logu
    print("Provedeno finally")

cislo: 12345
12345
Provedeno bez chyby
Provedeno finally
>>> try:
...     cislo = int(input("cislo: "))
...     print(cislo)
... except ValueError as err:
...     print(err)
... else:   #Blok se vykonna pouze, kdyz nebylo exception
...     print("Provedeno bez chyby")
... finally:    #Blok se provede VZDY - pri NOK i OK, napr. pro zapis do logu
...     print("Provedeno finally")
... 
cislo: 123asdas
invalid literal for int() with base 10: '123asdas'
Provedeno finally
>>> 
>>> #Jednoradkove verze prikazu
>>> i = 5
>>> if i > 0: print("Kuk!)
...                 
SyntaxError: incomplete input
>>> KeyboardInterrupt
>>> KeyboardInterrupt
>>> KeyboardInterrupt
...                 
<class 'KeyboardInterrupt'>
>>> KeyboardInterrupt
>>> KeyboardInterrupt
>>> 
>>> if i > 0: print("Kuk!")
... 
...                 
Kuk!
>>> #Lze pouzit i pro vice prikazu (oddelit pomoci stredniku ";" - vytvorime blok)
...                 
>>> if i > 0: print("Kuk!");print("Kuk2!")
... 
...             
Kuk!
Kuk2!
>>> 
>>> #Dokonce lze pridat i elif a else (na dalsi radek)
...                 
>>> #Podobne pro cykly while a for
...                 
>>> for i in range(1,6): k=2*i;print(k,k*k)
... 
...                 
2 4
4 16
6 36
8 64
10 100
