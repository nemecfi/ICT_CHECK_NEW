#Doplnkove prikazy
#Zruseni objektu (promenne)
i = 5
del i #smaze promennou i 
#Lze mazat i seznam
seznam = [1,2,3,4,5]
del seznam[2:4] #smaze index 2,3
print(seznam)
#lze mazat i podle hodnoty, nikoli indexu
seznam.remove(2) #vymaze 1 dvojku z leva
print(seznam)

#prirazeni vice promennych, zleva
a,b = 8,6
print(a,b)
#lze promenit promenne, bez pouziti 3. promenne:
a,b = b,a
print(a,b,"Prohozeni promennych")

#Prirazeni stejne hodnoty nekolika promennym
#Priradi hodnotu 99 do promennych a,b,c,d
a = b = c = d = 99
print(a,b,c,d, "Prirazeni 4 stejnych promennych najednou")

#Hvezdicka pro prirazeni seznamu (tuple apod.)
seznam = [1,2,3,4,5,6]
prvni,druhy,*zbytek = seznam #wildcard sebere zbytek seznamu a ulozi ho do promenne prvni[0],druhy[1],zbytek[2:]
print(prvni,druhy,zbytek)

#Operator prirazeni (Assignment expression), vraci prirazenou hodnotu

while(vstup := input("Napis Text:")) != "": #cist, dokud nezada prazdnou hodnotu
    print(vstup)

