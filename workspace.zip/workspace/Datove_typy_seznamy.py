#Datove typy
#Cela cisla jsou neomezena, limituje je jen pamet pocitace
#Rerezec -> string "" '' je to same
"String example"
'String example'

#Netistitelne / nepripstupne znamy - escepa sekvence (zacinaji \)
#Napr. odradkovani \n
a = "Prvni\nDruhy\nTreti"
print("Vypis promennych pomoci escape znaku\n",a)

#Promenne, stejne jako PS, akorat bez $
cislo = 5 #promena cislo, priradi typ INT, jelikoz je to cislo
type(cislo) #vrati typ hodnoty, v tomto pripade int

#Promenne jsou key sensitive!, zabudovane python promenne zacinaji "_"
#Pokud promenna zacina "_" tak je "soukroma" obcas tedy _ musime pouzit jako deklaraci private promenne

#V pythonu jsou vsechny typy "referencni", v podstate objekty, na ktery se vzdy promenna odkazuje pointerem
#Promenna obsahuje pointer na adresu, kde je vlastni hodnota
#Typy int a str jsou NEPROMENNE - pri kazde zmene se v pameti vytvori NOVA hodnota a pointer se na ni nasmeruje, pokud na starou hodnotu neodkazuje zadny pointer, tak ji garbage collector zrusi

#Typ seznam -> list, stejne jako ps ;) pristup do indexu 0-x
list = ["Nula",12,55,175,"Posledni index"]
print (list[2]) #Vypise index 2 z listu, delku listu lze zjistit prikazem len(list)
list.append(11) #Lze pridat dalsi hodnotu do listu, list jde i spojovat klasickym operatorem +
print(list)
list2 = ["Tohle","Jsou","Jen","Stringy"]
list_combined = list + list2 #Spojovat jdou jen seznamy, kdybych chtel pridat jednotlivou premonou, musim z ni udelat list, tedy list + [5], z promenne 5 jsem udelal jednoprvkovy seznam, ekvivalent prikazu append
print("Spojeni stringu: ",list_combined)

#Lze vytvorit novy seznam z casti jineho seznamu
list_piece = list_combined[1:6] #Vezmu cast seznamu od indexu 1 do indexu 6, lze vzit napriklad od zacatku nebo do konce [:6] [1:]      Lze pouzit i zaporne indexy, ktere berou hodnoty od konce -1 posledni -2 predposledni ...
print ("Ukrajovani listu pomoci indexu: ",list_piece)
#Seznamy jsou menitelne, lze menit jedlotlive prvky v seznamu, u nemenitelnych typu, napr "tuple" toto provest nelze
list2v2 = list2
list2v2[1] = "Nejsou"
print("Dukaz, ze list je menitelny objekt: ",list2) #Seznam je tedy propleteny pointerem a zmena v jednom seznamu provede zmenu ve druhem, jelikoz je to spolecny objekt, pokud ale chceme kopii dat a upravovat novou jinou verzi seznamu, tak lze pouzit rez
rez_listu2 = list2[:] #Toto vytvori novy objekt, ktery neni nijak spojeny s listem2, lze pouzit metodu copy

#Lze do seznamu vlozit data na urcity index aniz bych zmazal soucasna data
list2[1:1] = ["a","b"] #Vlozi data a,b na index 1 a dal, podle toho kolik dat je
print("od indexu 1 jsme pridali data a,b ",list2)
#Lze odmazat hodnoty v seznamu
list2[1:3] = [] # smazali jsme tedy hodnoty na indexu 1-3
print("Smazane indexy 1-3: ",list2)

seznam = [11,55,77,44,5,5214,552,663,87]
#seznam.sort() #Takto lze ulozit promennou jako sorted, kdyz chceme zachovat starou hodnotu ale chceme to seridit do nove, pouzijeme nasledujici:
print("\n",seznam)
seznamSort = sorted(seznam)
print ("Sorted:",seznamSort)

