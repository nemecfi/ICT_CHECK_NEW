#Cyklus while
x = 1
while (x < 10):
    print(x, x*x)
    x = x + 1

#Za False se povazuje: O,"",None,False,[] a prazdne dalsi viceprvkove typy
#True je vsechno ostatni, vcetne objektu, pravdivostni hodnotu ukazuje funkce bool
print("Bool na int 5: ",bool(5))
print("Bool na None: ",bool(None))

x = 9
while x: # konci hodnotou 0 -> Flase
    print(x,x*x)
    x = x - 1 #Az hodnota x bude 0, tak se status True zmeni na False
print ("\nFOR CYCLE\n")
#for cyclus se pouziva pro iterovatelne typy (list, string, ...)
#za iterovatelny se pythonu povazuje objekt, ktery muze jednotlive poskytovat sve cleny
staty = ["CR","SK","DE","FR","GB","KZ"]
for stat in staty:
    print(stat)


#lze iterovat i string a pridat napriklad podminku
for znak in "asjhadasodapoda":
    if znak in "aeiou":
        print(znak, "Samohlaska")
    else:
        print(znak,"Souhlaska")


#Klasicky for cyclus, kde je definovat rozsah cyklu
print ("\nKlasicky for cyklus")
for x in range(4,15):
    print (x,x*x)

#Cyklus for s krokem
print ("\nCyklus s krokem")
for x in range(1,10,2): #Range vraci 1,3,5,7,9 (3. parametr je krok, ktery navstavuje o 2)
    print(x, x*x)

#Vstup z klavesnice
input = int(input("Zadej cislo: ")) #vystup z klavesnice se ulozi do promenne input, ktera se rovnou zmeni ze str na int
print (input,type(input)) #Kdyz ale uzivatel nezada ciselnou hodnotu tak to vyhodi error, jelikoz text nejde konvertovat na int


