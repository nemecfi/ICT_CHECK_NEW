#Ridici prikazy
#Podmineny prikaz if: v pythonu se blok kodu neoznacuje {} ale odsazenim
a, b, c = 0, 0, 0

if (a > 0):
    b = 1
    c = 3   #blok prikazu (suite), ktery se vykona pri splneni podminky
else:
    b = 9999
    c = 666 #blok prikazu, ktery se vykona kdyz neni podminka splnena

print("Example 1: ",a,b,c)

#Prikazy if lze vnorovat, opet s odsazenim
#Prikaz "pass" nedela nic, je to prazdny prikaz aby v te podmince aspon neco bylo, jelikoz podminka nemuze byt prazdna
a, b, c = 0, 0, 0

if (a == 0):
   pass #kdyz je podminka splnena, tak se nic nevykona
else:
    b = 9999
    c = 666 #blok prikazu, ktery se vykona kdyz neni podminka splnena

print("Example 2: ",a,b,c)

#Vicenasobne vetveni
teplota = -55
if (teplota > 25):
    print("Vedro")
elif (teplota > 20):
    print("Teplo")
elif (teplota > 17):
    print("Prijemne")
# ... 
elif (teplota > 0):
    print("Nemrzne")
else:
    print("Zima") 