# program cte data ze vstupu
# vstup = True
# total = 0
# count = 0
# print("Pro ukonceni programu zadejte prazdny retezec")
# while True:
#
#    userInput = input("Zadejte cislo: ")
#    if userInput:  # Neni-li prazdny retezec
#        if userInput.isdigit():
#            cislo = int(userInput)
#            total += cislo  # Scitani cisla do promenne total
#            count += 1  # Uklada pocet cisel, ktere uzivatel vypsal
#        else:
#            print("Uzivatel nezadal ciselnou hodnotu, zkuste to znovu")
#            #break
#    else:
#        break  # Ukonci cyklus
# if count:
#    print("\nPocet = ", count, "\nSoucet = ",
#          total, "\nPrumer = ", total/count)
#
# else:
#    print("\nNebylo pridane zadne platne cislo")
#

# Pouziti try, except misto isdigit()




# program cte data ze vstupu
# vstup = True
total = 0
count = 0
print("Pro ukonceni programu zadejte prazdny retezec")
while True:

    userInput = input("Zadejte cislo: ")
    if userInput:  # Neni-li prazdny retezec
        try: #V podstate stejne jako Try / catch
            cislo = int(userInput)
        except ValueError as err:
        #except: Lze zapsat jednoduse jen except:
            print(err)
            continue #Zacni novy cyklus od zacatku

        total += cislo  # Scitani cisla do promenne total
        count += 1  # Uklada pocet cisel, ktere uzivatel vypsal
    else:
        break  # Ukonci cyklus
if count:
    print("\nPocet = ", count, "\nSoucet = ",
        total, "\nPrumer = ", total/count)

else:
    print("\nNebylo pridane zadne platne cislo")
