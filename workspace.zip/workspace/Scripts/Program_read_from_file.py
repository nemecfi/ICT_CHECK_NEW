#Program cte cisla primo ze souboru (.txt)
#program_read_from_file.py < numbers.txt

total = 0
count = 0
print("Pro ukonceni programu zadejte prazdny retezec")
while True:
    try:
        line = input()
        if (line != ""):
            number = int(line)
            #Vyvolani dobrovolne vyjimky, nejedna se o chybu ale rozhodnuti
            if (number <= 0):
                raise ValueError("Cislo ",number, " neni kladne")
            else:
                total += number
                count += 1
        else:
            break #Ukonceni programu          
    except ValueError as err:
        print(err)
        continue #Dalsi cyklus
    except EOFError as err: #Konec sourobur
        print("Konec souboru")
        break
    #Osetreni obecneho exceptionu (napsat vzdy nakonec)
    #Vypsat co nejvice informaci
    except Exception as err:
        print("Neocekavana chyba: ",err.__class__)
        print(err)
        break
    
if count !=0:
    print("\nPocet = ", count, "\nSoucet = ",total, "\nPrumer = ", total/count)

else:
    print("\nNebylo pridane zadne platne cislo")
