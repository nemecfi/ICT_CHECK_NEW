#Program vypisuje cislo zadane jako parametr v cmd
#Cislo vypisuji pomoci velkych cislic vytvorenych hvezdickami
#VelkeCislice.py 3456

import sys #Import modulu sys (kvuli cteni parametru v cmd)

Zero = ["   ***   ",
        " *     * ",
        "*       *",
        "*       *",
        "*       *",
        " *     * ",
        "   ***   "]
One = [" * ", "** ", " * ", " * ", " * ", " * ", "***"]
Two = [" *** ", "*   *", "*  * ", "  *  ", " *   ", "*    ", "*****"]
Three = [" *** ", "*   *", "    *", "  ** ", "    *", "*   *", " *** "]
Four = ["   *  ", "  **  ", " * *  ", "*  *  ", "******", "   *  ", "   *  "]
Five = ["*****", "*    ", "*    ", " *** ", "    *", "*   *", " *** "]
Six = [" *** ", "*    ", "*    ", "**** ", "*   *", "*   *", " *** "]
Seven = ["*****", "    *", "   * ", "  *  ", " *   ", "*    ", "*    "]
Eight = [" *** ", "*   *", "*   *", " *** ", "*   *", "*   *", " *** "]
Nine = [" ****", "*   *", "*   *", " ****", "    *", "    *", "    *"]
Digits = [Zero,One,Two,Three,Four,Five,Six,Seven,Eight,Nine]
try:
    cisla = sys.argv[1] #2. (index 1) argument cmd (prvni - index 0 je jmeno programu vcetne cesty)

    for indexHvezdicek in range(0,7):
        line = "" #budouci radek hvezdicek
        for cislo in cisla: #
            indexCislice = int(cislo) #Konverze na int
            velkaCislice = Digits[indexCislice]
            line += velkaCislice[indexHvezdicek] + "   " #Odsazeni mezi cislicema
        print(line)

except IndexError as err:
    print("Chyba:",err,"\n",sys.argv[0],"<cislo>")
except ValueError as err:
    print("Chybne zadane cislo:",cisla)

#for Digit in Digits:
#    print(Digit)