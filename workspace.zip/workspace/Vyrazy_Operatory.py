#doc: https://www.w3schools.com/python/python_operators.asp
#Operatory aritmeticke + - * / VZDY DESETINNE // Celociselne
#Modulo (zbytek po deleni) %
print("Desetinne", 5 / 2)
print("Celocislene: ", 5 // 2)
# ** mocnina
#Slozene operatory += -= *=
a = 5
i = 1
i += 2 # Stejne jako i = i + 2
print("i = ",i)

#cislo = "cislo = " + 5 # chyba Python nekonvetruje automaticky cislo na retezec pro operator +, konverze musime udelat manualne:
cislo = "cislo = " + str(5) #toto z intu 5 udela string "5", nyni lze stejne datove typy spojit
print("spojeni stringu, pomoci koverze:",cislo)

#releacni operatory < <= >= != (nerovno) == (rovno)
#Operator identity "is" - porovnava POINTERY (adresy v pameti), NIKOLI hodnoty
a = 5
b = 5
print("Porovnani stejne adresy v pameti: ",a is b) #Nyni je to true, jelikoz odkazuji na stejnou adresu v pameti, kde je ulozena hodnota 5
s1 = [1,2,3]
s2 = [1,2,3]
print("Stejny obsah listu ale jina adresa v pameti: ",s1 is s2) #Nyni je to false, jelikoz kazdy seznam ma jinou adresu pameti, proto by bylo vhodne pouzit operator == 
#is se obvykle pouziva pro testovani specialni hodnoty NONE - preddefinova hodna -> nezname, neplatne, nedefinovane
c = None
print("Kontrola jestli je C None: ",c is None)

#Operatory logicke not, and, or (spojovani podminek), priority operatoru lze najit v helpu
i = 5
(i < 0) and (p - 3 != 7) #Vyhodnocuje ZLEVA a konci, je-li vysledek jasny.  Jelikoz je leva strana vyrazu False, tak se na druhou stranu ani nedostane, kde by byla syntax chyba, jelikoz p neni definovano
i < b < 7 #Kompaktni zapis podminem (bez and - misto i < b and b < 7)

#Relacni operatory lze pouzit i pro seznamy a dalsi viceprvkove typy: for cyclus provadi python automaticky a projede kazdou hodnotu v listu. Vzdy se porovna index 0 oproti indexu 0 druheho seznamu, kdyz je true, cyklus pokracuje dale
print("Kontrola 2 listu: "[1,3,"Ahoj",4] == [1,3,"Ahoj",5])
#Jsou-li seznamy ruzne dlouhe, povazuji se tyto seznamy za neshodne
#Pro nektera porovnanvani mohou mit seznamy NEKOMPATIBILNI typy (2 == "Franta") - false, pro jina vznikne chyba napr (2 > "Franta") - syntax err, jelikoz tato metoda neumi pracovat s int a str zaroven
#Je-li prvkem sezanmu zase seznam, postupuje se rekurzivne, u stringu se porovnavaji hodnoty kodovych bodu v UNICODE (NEMUSI udelat "spravne" porovnani)
seznam = []
seznam += ["AHOJ"]
print(seznam)